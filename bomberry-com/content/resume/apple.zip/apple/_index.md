+++
title = "Kevin Bomberry - Resume - Apple"
date = 2018-05-05T23:11:05-07:00
draft = true
weight = 3
company_name = "Apple"
location_name = "resume"
keywords = []
+++
<h6>resume/apple/-index</h6>
<section>
  <a id="introduction"></a>
  <div class="container">
    <div class="row color-resume">
      <div class="col-md-10 col-md-offset-1 text-left">
        <h1>Hello Apple</h1>
      </div>
    </div>
    <hr>
    <div class="row color-resume">
      <div class="col-md-5 col-md-offset-1 text-left">
        <h2>Kevin Bomberry</h2>
      </div>
      <div class="col-md-5 text-right">
        <h2>R&eacute;sum&eacute;</h2>
      </div>
    </div>
    <hr>
    <div class="row">
      <div class="col-md-10 col-md-offset-1 text-left">
        <h6>resume/-index</h6>
        <h3 class="text-tall">25+ years of success working with amazing companies including Adobe, IDEO, Microsoft, and the MIT/Stanford Venture Lab (VLAB)</h3>
        <p class="lead">For the past 6+ years I’ve been directly involved in Adobe’s direction in 3D including 3D in Photoshop, 3D Printing, and Project Felix, as well as influencing additional Adobe titles, keeping my focus on 3D, AR/VR, and touch/mobile UX/IxD all the while.</p>
      </div>
    </div>
  </div>
</section>
